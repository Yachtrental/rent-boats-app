# rent-boats-app
React + Vite + TailwindCSS boat rental platform: listings, booking flows, Stripe, and admin dashboard.
